
import 'package:calculator_bmi/pages/result_page.dart';
import 'package:calculator_bmi/pages/result_page_mifflin.dart';
import 'package:calculator_bmi/pages/reusable_card.dart';
import 'package:calculator_bmi/util/calculator_imc.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import '../util/calculator_mifflin.dart';
import '../util/const.dart';
import '../util/strings.dart';
import 'icon_content.dart';

class InputPage extends StatefulWidget {
  const InputPage({Key? key}) : super(key: key);
  @override
  _InputPageState createState() => _InputPageState();
}

enum Gender{
  masculine,
  femme
}

class _InputPageState extends State<InputPage> {
  Gender? selectedGender;
  double valueSlider = 0;
  double counterAge = 50.0;
   double counterWeight = 80.0;

   void addAge() {
  setState(() {
    counterAge++;
  });
}

void minusAge() {
  setState(() {
    if (counterAge > 1) {
      counterAge--;
    }
  });
}

  void addWeight() {
  setState(() {
    counterWeight++;
  });
}

void minusWeight() {
  setState(() {
    if (counterWeight != 0) {
      counterWeight--;
    }
  });
}

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kSecundaryColor,
      appBar: AppBar(
        title: const Text(
          sAppTittle,
          style: TextStyle(
            color: kPrimaryTextColor,
          ),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: Row(
              children: [
                 Expanded(
                  child: GestureDetector(
                    onTap: (){
                      setState(() {
                         selectedGender = Gender.masculine;
                      });  
                    },
                    child: ReusableCard(
                    cardColor: selectedGender == Gender.masculine? kActiveCardColor : kInactiveCardColor,
                    cardChild: const IconContent(
                      cardIcon: FontAwesomeIcons.mars, cardLabel: sLabelMasculine, 
                      cardIconColor: kIconInactiveColor,
                      ),
                                  ),
                  )),
                Expanded(
                    child: GestureDetector(
                      onTap: () {
                        setState(() {
                          selectedGender = Gender.femme;
                        });
                      },
                      child: ReusableCard(
                      cardColor: selectedGender == Gender.femme? kActiveCardColor : kInactiveCardColor,
                      cardChild: const IconContent(
                      cardIcon: FontAwesomeIcons.venus, cardLabel: sLabelFemennine,
                      cardIconColor: kIconInactiveColor,),
                                    ),
                    )),
              ],
            ),
          ),
           Expanded(
            child: ReusableCard(
            cardChild: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children:  [
                const Text('Altura', style: kTextLabelStyleGeneral,),
                Row(
                   mainAxisAlignment: MainAxisAlignment.center,
                  textBaseline: TextBaseline.alphabetic,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children:  [
                   Text('${valueSlider.round()}', style: kTextLabelStyle,),
                  const Text('cm', style: kTextLabelStyle,)
                  ],
                ),
                SliderTheme(
                  data: SliderTheme.of(context).copyWith(
                    trackHeight: 10,
                    activeTrackColor: kBoxMainColor,
                    inactiveTrackColor: kBoxResultColor,
                    thumbColor: kBoxResultColor,
                  ),
                  child: Slider(
                    value: valueSlider, 
                    max: 220,
                    activeColor: kColorAl,
                    onChanged: (valor){
                      setState(() {
                        valueSlider = valor;
                      });    
                    },
                    ),
                ),
              ],
            ),
            cardColor: kBoxMainColor,
          ),
          ),
          Expanded(
            child: Row(
              children:  [
                Expanded(
                    child: ReusableCard(
                      cardChild: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children:  [
                          const Text('Edad', style: kTextLabelStyleGeneral,),
                           Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              textBaseline: TextBaseline.alphabetic,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children:  [
                              Text('${counterAge.round()}', style: kTextLabelStyleGeneral,),
                             ],
                           ),
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                             textBaseline: TextBaseline.alphabetic,
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              FloatingActionButton(
                                onPressed: addAge,
                                child: const Icon(Icons.add, color: kIconActiveColor,),
                                backgroundColor: Colors.white,
                                ),
                                FloatingActionButton(
                                onPressed: minusAge,
                                child: const Icon(Icons.minimize, color: kIconActiveColor),
                                backgroundColor: Colors.white,
                                ),
                            ],
                          ),
                        ],
                      
    ),
                      cardColor: kBoxMainColor,
                ),
                ),
                 Expanded(
                    child: ReusableCard(
                    cardChild: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children:  [
                          const Text('Peso', style: kTextLabelStyleGeneral,),
                           Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              textBaseline: TextBaseline.alphabetic,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children:  [
                              Text('${counterWeight.round()}', style: kTextLabelStyleGeneral,),
                              const Text('kg', style: kTextLabelStyleGeneral,)
                             ],
                           ),
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                             textBaseline: TextBaseline.alphabetic,
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              FloatingActionButton(
                                onPressed: addWeight,
                                child: const Icon(Icons.add, color: kIconActiveColor,),
                                backgroundColor: Colors.white,
                                ),
                                FloatingActionButton(
                                onPressed: minusWeight,
                                child: const Icon(Icons.minimize, color: kIconActiveColor),
                                backgroundColor: Colors.white,
                                ),
                            ],
                          ),
                        ],
                      
      
    ),
                  cardColor: kBoxMainColor,
                ),
                ),
              ],
            ),
          ),
          Row(
            children: [
              Expanded(
                child: Container(
                  color: kBoxResultColor,
                  margin: const EdgeInsets.only(top: 10),
                  width: double.infinity,
                  height: 80,
                  child: ElevatedButton(
                    child: const Text('IMC'),
                    onPressed: (){
                      CalculatorIMC calculo = CalculatorIMC(
                        height: valueSlider,
                      weight: counterWeight);
                      Navigator.push(context, 
                      MaterialPageRoute(builder: (context) => ResultPage(
                        imcResult: calculo.calculateIMC(), 
                        resultText: calculo.getResult(), 
                        interpretation: calculo.getInterpretation()),
                        ),
                        );
                         },
                    ),
                ),
              ),
              Expanded(
                child: GestureDetector(
                  onTap: (){
                    setState(() {
                      selectedGender = Gender.masculine;
                    });
                  },
                  child: Container(
                    color: kBoxResultColor,
                    margin: const EdgeInsets.only(top: 10),
                    width: double.infinity,
                    height: 80,
                    child: ElevatedButton(
                      child: const Text('Mifflin'),
                      onPressed: (){
                        CalculatorMifflin calculo = CalculatorMifflin(
                          age: counterAge,
                          gender: selectedGender == Gender.masculine ? 'Masculino' : 'Femenino',
                          height: valueSlider,
                        weight: counterWeight);
                        Navigator.push(context, 
                        MaterialPageRoute(builder: (context) => ResultPageMifflin(
                          genderResult: calculo.genderSelected(), 
                          mifflinResult: calculo.calculateMifflin(), 
                          ),
                          ),
                          );
                           },
                      ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

