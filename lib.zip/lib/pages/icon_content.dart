import 'package:flutter/material.dart';


class IconContent extends StatelessWidget {
  final IconData cardIcon;
  final String  cardLabel;
  final Color cardIconColor;

  const IconContent({
    Key? key,
    required this.cardIcon,
    required this.cardLabel,
    required this.cardIconColor,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(cardIcon, size: 80, color: cardIconColor),
        const SizedBox(height: 15),
        Text(cardLabel)
      ],
    );
  }
}
