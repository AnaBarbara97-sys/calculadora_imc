import 'package:calculator_bmi/pages/reusable_card.dart';
import 'package:calculator_bmi/util/const.dart';
import 'package:flutter/material.dart';

class ResultPage extends StatelessWidget {

  final String imcResult;
  final String resultText;
  final String interpretation;

  const ResultPage({ Key? key, required this.imcResult,
  required this.resultText,
  required this.interpretation }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kSecundaryColor,
      appBar: AppBar(
        title:  const Text('IMC'),
      ),
   body: Column(
     crossAxisAlignment: CrossAxisAlignment.stretch,
     children:  [
       const Center(child: Text('TU RESULTADO', style: kTextLabelStyleImcMifflin)),
       Expanded(
         child: ReusableCard(
          cardColor: kBoxMainColor,
         cardChild: Column(
           mainAxisAlignment: MainAxisAlignment.spaceEvenly,
           children:  [
             Text(resultText, style: kTextLabelStyleImcMifflin,),
             const Divider(
               color: Colors.white,
             ),
               const Text('IMC', style: kTextLabelStyleImcMifflin,),
             Text(imcResult, style: kTextLabelStyleImcMifflin,),
             const Divider(
               color: Colors.white,
             ),
               const Text('Recomendaciones', style: kTextLabelStyleImcMifflin,),
             Text(interpretation, style: kTextLabelStyleImcMifflin,),
           ],
         ),)
         ),
          Container(
            color: kBoxResultColor,
            margin: const EdgeInsets.only(top: 10),
            width: double.infinity,
            height: 80,
            child: ElevatedButton(
              child: const Text('Re-calcular'),
              onPressed: (){
                Navigator.pop(context);
              }, 
              ),
          ),
     ],
   ),
    
        );
  }
}