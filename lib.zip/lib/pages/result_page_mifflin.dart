
import 'package:flutter/material.dart';

import '../util/const.dart';
import 'reusable_card.dart';

class ResultPageMifflin extends StatelessWidget {
  final String genderResult;
  final String mifflinResult;

  const ResultPageMifflin({ Key? key, required this.genderResult,
  required this.mifflinResult }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kSecundaryColor,
      appBar: AppBar(
        title:  const Text('Mifflin'),
      ),
   body: Column(
     crossAxisAlignment: CrossAxisAlignment.stretch,
     children:  [
       const Center(child: Text('TU RESULTADO', style: kTextLabelStyleImcMifflin,)),
       Expanded(
         child: ReusableCard(
          cardColor: kBoxMainColor,
         cardChild: Column(
           mainAxisAlignment: MainAxisAlignment.spaceEvenly,
           children:  [
             const Text('Género', style: kTextLabelStyleImcMifflin,),
             Text(genderResult, style: kTextLabelStyleImcMifflin,),
             const Divider(
               color: Colors.white,
             ),
             const Text('Gasto Energético Basal', style: kTextLabelStyleImcMifflin,),
             Text(mifflinResult, style: kTextLabelStyleImcMifflin,),
           ],
         ),)
         ),
          Container(
            color: kBoxResultColor,
            margin: const EdgeInsets.only(top: 10),
            width: double.infinity,
            height: 80,
            child: ElevatedButton(
              child: const Text('Re-calcular'),
              onPressed: (){
                Navigator.pop(context);
              }, 
              ),
          ),
     ],
   ),
    
        );
  }
}