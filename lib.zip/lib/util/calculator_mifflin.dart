
class CalculatorMifflin{

  CalculatorMifflin({required this.height, required this.weight, required this.age, required this.gender});

  final double height;
  final double weight;
  final double age;
  double mifflin = 0;
  String gender;


 String genderSelected(){
   if(gender == "Masculino"){
     return "Eres un hombre";
   } else if(gender == "Femenino"){
     return "Eres una mujer";
   }else{
     return "Sin información";
   }
 }

 String calculateMifflin(){
   if(gender == "Masculino"){
     mifflin = (10 * weight) + (6.25 * height) - (5 * age) + 5;
     return mifflin.toStringAsFixed(1);
   } else if(gender == "Femenino"){
     mifflin = (10 * weight) + (6.25 * height) - (5 * age) - 161;
     return mifflin.toStringAsFixed(2);
   }else{
     return "No hay resultados disponibles";
   }
 }
  
}