// Este archivo contiene todos los textos estáticos de la app
const String sAppTittle = "BMI CALCULATOR";

// Textos de las cajas
const String sLabelMasculine = 'MASCULINE';
const String sLabelFemennine = 'FEMENINE';

