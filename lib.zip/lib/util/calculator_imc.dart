import 'dart:math';

class CalculatorIMC{
  
  CalculatorIMC({required this.height, required this.weight,  });

  final double height;
  final double weight;
  double imc = 0;

  String calculateIMC(){
     imc = weight / pow(height / 100 , 2);
    return imc.toStringAsFixed(1);
  }

  String getResult(){
    if(imc >= 30){
      return 'Obesidad';
    } else if(imc >= 25){
      return 'Sobrepeso';
    } else if(imc >= 18.5){
      return 'Normal';
    } else{
      return 'Bajo peso';
    }
  }

  String getInterpretation(){
    if(imc >= 30){
    return 'Te recomiendo hacer ejercicio y comer sano, ya que, al subir mas de peso afectará tu salud.';
    } else if(imc >= 25){
      return 'Te recomiendo tomar líquidos y salir a caminar para mejorar tu metabolismo.';
    } else if(imc >= 18.5 ){
      return 'Tu peso esta normal, sigue manteniendote así';
    } else{
      return 'Come alimentos altos en potasio y en vitaminas para mejorar tu salud.';
    }
  }
}