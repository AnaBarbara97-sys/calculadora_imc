import 'package:calculator_bmi/pages/input_page.dart';
import 'package:flutter/material.dart';

import 'package:calculator_bmi/util/const.dart';



void main() => runApp(const BMICalculator());

class BMICalculator extends StatelessWidget {
  const BMICalculator({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    final ThemeData theme = ThemeData();
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: theme.copyWith(
        colorScheme: theme.colorScheme.copyWith(
          primary: kPrimaryColor,
        ),
      ),
      initialRoute: '/',
      routes: {
        '/':(context) => const InputPage(),
      },      
    );
  }
}
